﻿namespace Standard_Books.Custom_Controls
{
    partial class Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbxDua = new System.Windows.Forms.PictureBox();
            this.pbxSB = new System.Windows.Forms.PictureBox();
            this.pbxYahoo = new System.Windows.Forms.PictureBox();
            this.pbxOutlook = new System.Windows.Forms.PictureBox();
            this.pbxTwitter = new System.Windows.Forms.PictureBox();
            this.pbxGmail = new System.Windows.Forms.PictureBox();
            this.pbxfacebook = new System.Windows.Forms.PictureBox();
            this.pbxlogo = new System.Windows.Forms.PictureBox();
            this.pbxWebster = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYahoo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOutlook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTwitter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxfacebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxlogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWebster)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxDua
            // 
            this.pbxDua.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxDua.Image = global::Standard_Books.Properties.Resources.bismillah;
            this.pbxDua.Location = new System.Drawing.Point(125, 2);
            this.pbxDua.Name = "pbxDua";
            this.pbxDua.Size = new System.Drawing.Size(634, 110);
            this.pbxDua.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxDua.TabIndex = 3;
            this.pbxDua.TabStop = false;
            // 
            // pbxSB
            // 
            this.pbxSB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxSB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxSB.Image = global::Standard_Books.Properties.Resources.sb;
            this.pbxSB.Location = new System.Drawing.Point(570, 466);
            this.pbxSB.Name = "pbxSB";
            this.pbxSB.Size = new System.Drawing.Size(47, 43);
            this.pbxSB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxSB.TabIndex = 2;
            this.pbxSB.TabStop = false;
            this.pbxSB.Click += new System.EventHandler(this.pbxSB_Click);
            // 
            // pbxYahoo
            // 
            this.pbxYahoo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxYahoo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxYahoo.Image = global::Standard_Books.Properties.Resources.yahoo;
            this.pbxYahoo.Location = new System.Drawing.Point(623, 466);
            this.pbxYahoo.Name = "pbxYahoo";
            this.pbxYahoo.Size = new System.Drawing.Size(47, 43);
            this.pbxYahoo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxYahoo.TabIndex = 2;
            this.pbxYahoo.TabStop = false;
            this.pbxYahoo.Click += new System.EventHandler(this.pbxYahoo_Click);
            // 
            // pbxOutlook
            // 
            this.pbxOutlook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxOutlook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxOutlook.Image = global::Standard_Books.Properties.Resources.outlook;
            this.pbxOutlook.Location = new System.Drawing.Point(676, 466);
            this.pbxOutlook.Name = "pbxOutlook";
            this.pbxOutlook.Size = new System.Drawing.Size(47, 43);
            this.pbxOutlook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOutlook.TabIndex = 2;
            this.pbxOutlook.TabStop = false;
            this.pbxOutlook.Click += new System.EventHandler(this.pbxOutlook_Click);
            // 
            // pbxTwitter
            // 
            this.pbxTwitter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxTwitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxTwitter.Image = global::Standard_Books.Properties.Resources.twitter;
            this.pbxTwitter.Location = new System.Drawing.Point(729, 466);
            this.pbxTwitter.Name = "pbxTwitter";
            this.pbxTwitter.Size = new System.Drawing.Size(47, 43);
            this.pbxTwitter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxTwitter.TabIndex = 2;
            this.pbxTwitter.TabStop = false;
            this.pbxTwitter.Click += new System.EventHandler(this.pbxTwitter_Click);
            // 
            // pbxGmail
            // 
            this.pbxGmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxGmail.Image = global::Standard_Books.Properties.Resources.gmail;
            this.pbxGmail.Location = new System.Drawing.Point(782, 466);
            this.pbxGmail.Name = "pbxGmail";
            this.pbxGmail.Size = new System.Drawing.Size(47, 43);
            this.pbxGmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGmail.TabIndex = 2;
            this.pbxGmail.TabStop = false;
            this.pbxGmail.Click += new System.EventHandler(this.pbxGmail_Click);
            // 
            // pbxfacebook
            // 
            this.pbxfacebook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxfacebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxfacebook.Image = global::Standard_Books.Properties.Resources.facebook;
            this.pbxfacebook.Location = new System.Drawing.Point(835, 466);
            this.pbxfacebook.Name = "pbxfacebook";
            this.pbxfacebook.Size = new System.Drawing.Size(47, 43);
            this.pbxfacebook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxfacebook.TabIndex = 2;
            this.pbxfacebook.TabStop = false;
            this.pbxfacebook.Click += new System.EventHandler(this.pbxfacebook_Click);
            // 
            // pbxlogo
            // 
            this.pbxlogo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbxlogo.Image = global::Standard_Books.Properties.Resources.logo;
            this.pbxlogo.Location = new System.Drawing.Point(0, 0);
            this.pbxlogo.Name = "pbxlogo";
            this.pbxlogo.Size = new System.Drawing.Size(885, 512);
            this.pbxlogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbxlogo.TabIndex = 1;
            this.pbxlogo.TabStop = false;
            // 
            // pbxWebster
            // 
            this.pbxWebster.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pbxWebster.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxWebster.Image = global::Standard_Books.Properties.Resources.webster_title;
            this.pbxWebster.Location = new System.Drawing.Point(3, 453);
            this.pbxWebster.Name = "pbxWebster";
            this.pbxWebster.Size = new System.Drawing.Size(130, 56);
            this.pbxWebster.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxWebster.TabIndex = 2;
            this.pbxWebster.TabStop = false;
            this.pbxWebster.Click += new System.EventHandler(this.pbxWebster_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pbxDua);
            this.Controls.Add(this.pbxWebster);
            this.Controls.Add(this.pbxSB);
            this.Controls.Add(this.pbxYahoo);
            this.Controls.Add(this.pbxOutlook);
            this.Controls.Add(this.pbxTwitter);
            this.Controls.Add(this.pbxGmail);
            this.Controls.Add(this.pbxfacebook);
            this.Controls.Add(this.pbxlogo);
            this.Name = "Home";
            this.Size = new System.Drawing.Size(885, 512);
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYahoo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOutlook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTwitter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxfacebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxlogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWebster)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxlogo;
        private System.Windows.Forms.PictureBox pbxfacebook;
        private System.Windows.Forms.PictureBox pbxGmail;
        private System.Windows.Forms.PictureBox pbxTwitter;
        private System.Windows.Forms.PictureBox pbxOutlook;
        private System.Windows.Forms.PictureBox pbxYahoo;
        private System.Windows.Forms.PictureBox pbxSB;
        private System.Windows.Forms.PictureBox pbxDua;
        private System.Windows.Forms.PictureBox pbxWebster;
    }
}
